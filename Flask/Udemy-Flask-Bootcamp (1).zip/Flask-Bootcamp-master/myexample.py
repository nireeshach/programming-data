# myexample.py
puppies = 6
weight = 2

total_weight = puppies * weight

print(total_weight)
